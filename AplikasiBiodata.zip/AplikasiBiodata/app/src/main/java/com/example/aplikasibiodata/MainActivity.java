package com.example.aplikasibiodata;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void waClick (View view) {
        goToUrl ( "http://wa.me/6282234544188");
    }
    public void mapsClick (View view) {
        goToUrl ( "https://goo.gl/maps/6jUmJAMvGr6ZVYDf8");
    }
    public void telpClick (View view) {
        goToUrl ( "tel:+6282234544188");
    }
    public void emailClick (View view) {
        goToUrl ( "mailto:harrybopra@gmail.com");
    }

    private void goToUrl (String url) {
        Uri uriUrl = Uri.parse(url);
        Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
        startActivity(launchBrowser);
    }
}